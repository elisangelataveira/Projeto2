package datagramasocket;

import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Client extends JFrame implements ActionListener {
   private JTextField enter;
   private JTextArea display;

   private DatagramPacket sendPacket, receivePacket;
   private DatagramSocket socket;

   public Client()
   {
      super( "Cliente" );

      enter = new JTextField( "Digite a mensagem aqui" );
      enter.addActionListener( this );
      getContentPane().add( enter, BorderLayout.NORTH );
      display = new JTextArea();
      getContentPane().add( new JScrollPane( display ),
                            BorderLayout.CENTER );
      setSize( 400, 300 );
      show();

      try {
         socket = new DatagramSocket();
      }
      catch( SocketException se ) {
         se.printStackTrace();
         System.exit( 1 );
      }
   }

   public void waitForPackets()
   {
      while ( true ) {
         try {
            // criar pacotes
            byte data[] = new byte[ 100 ];
            receivePacket =
               new DatagramPacket( data, data.length );

            // receber pacotes
            socket.receive( receivePacket );
 
            // processar pacotes
            display.append( "\nPacote recebido:" +
               "\nDe host: " + receivePacket.getAddress() +
               "\nPorta do host: " + receivePacket.getPort() +
               "\nComprimento: " + receivePacket.getLength() +
               "\nContendo:\n\t" +
               new String( receivePacket.getData(), 0,
                           receivePacket.getLength() ) );
               display.setCaretPosition(
                  display.getText().length() );
         }
         catch( IOException exception ) {
            display.append( exception.toString() + "\n" );
            exception.printStackTrace();
         }
      }
   }

   public void actionPerformed( ActionEvent e )
   {
      try {
         display.append( "\nEnviando pacote contendo: " +
                         e.getActionCommand() + "\n" );

         String s = e.getActionCommand();
         byte data[] = s.getBytes();

         sendPacket = new DatagramPacket( data, data.length,
            InetAddress.getLocalHost(),5000);
         socket.send( sendPacket );
         display.append( "Pacote enviado\n" );
         display.setCaretPosition(
            display.getText().length() );

      }
      catch ( IOException exception ) {
         display.append( exception.toString() + "\n" );
         exception.printStackTrace();
      }
   }

   public static void main( String args[] )
   {
      Client app = new Client();

      app.addWindowListener(
         new WindowAdapter() {
            public void windowClosing( WindowEvent e )
            {
               System.exit( 0 );
            }
         }
      );

      app.waitForPackets();
   }
}

