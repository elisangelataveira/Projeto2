

package datagramasocket;

import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Server extends JFrame {
   private JTextArea display;

   private DatagramPacket sendPacket, receivePacket;
   private DatagramSocket socket;

   public Server()
   {
      super( "Servidor" );

      display = new JTextArea();
      getContentPane().add( new JScrollPane( display),
                            BorderLayout.CENTER );
      setSize( 400, 300 );
      show();

      try {
         socket = new DatagramSocket(5000);
      }
      catch( SocketException se ) {
         se.printStackTrace();
         System.exit( 1 );
      }
   }

   public void waitForPackets()
   {
      while ( true ) {
         try {
            // criar pacotes
            byte data[] = new byte[ 100 ];
            receivePacket =
               new DatagramPacket( data, data.length );

            // receber pacotes
            socket.receive( receivePacket );
 
            // processar pacotes
            display.append( "\nPacote recebido:" +
               "\nDe host: " + receivePacket.getAddress() +
               "\nPorta do host: " + receivePacket.getPort() +
               "\nComprimento: " + receivePacket.getLength() +
               "\nContendo:\n\t" +
               new String( receivePacket.getData(), 0,
                           receivePacket.getLength() ) );

            // ecoar informações do pacote de volta para o cliente
            display.append( "\n\nEnviar pacote de volta para o cliente...");
            sendPacket =
               new DatagramPacket( receivePacket.getData(),
                                   receivePacket.getLength(),
                                   receivePacket.getAddress(),
                                   receivePacket.getPort() );
            socket.send( sendPacket );
            display.append( "Pacote enviado\n" );
            display.setCaretPosition(
               display.getText().length() );
         }
         catch( IOException io ) {
            display.append( io.toString() + "\n" );
            io.printStackTrace();
         }
      }
   }

   public static void main( String args[] )
   {
      Server app = new Server();

      app.addWindowListener(
         new WindowAdapter() {
            public void windowClosing( WindowEvent e )
            {
               System.exit( 0 );
            }
         }
      );

      app.waitForPackets();
   }
}

