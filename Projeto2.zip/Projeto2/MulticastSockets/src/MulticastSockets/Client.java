
package MulticastSockets;

import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Client extends JFrame implements ActionListener {
   private JTextField enter;
   private JTextArea display;

   private DatagramPacket sendPacket, receivePacket;
   private MulticastSocket socket;
   private int porta = 5000;
   private InetAddress grupo;

   public Client()
   {
      super( "Cliente" );

      enter = new JTextField( "Digite a mensagem aqui" );
      enter.addActionListener( this );
      getContentPane().add( enter, BorderLayout.NORTH );
      display = new JTextArea();
      getContentPane().add( new JScrollPane( display ),
                            BorderLayout.CENTER );
      setSize( 400, 300 );
      show();

      try {
         socket = new MulticastSocket(porta);
         grupo = InetAddress.getByName("230.1.2.3");
         socket.joinGroup(grupo);
      }
      catch( IOException se ) {
         se.printStackTrace();
         System.exit( 1 );
      }

   }

   public void waitForPackets()
   {
      while ( true ) {
         try {
            // construir o pacote 
            byte data[] = new byte[ 100 ];
            receivePacket =
               new DatagramPacket( data, data.length );

            // receber pacote
            socket.receive( receivePacket );
 
            // processar pacote
            display.append( "\nPacote recebido:" +
               "\nDe host: " + receivePacket.getAddress() +
               "\nPorta do Host: " + receivePacket.getPort() +
               "\nTamanho: " + receivePacket.getLength() +
               "\nContendo:\n\t" +
               new String( receivePacket.getData(), 0,
                           receivePacket.getLength() ) );
               display.setCaretPosition(
                  display.getText().length() );
         }
         catch( IOException exception ) {
            display.append( exception.toString() + "\n" );
            exception.printStackTrace();
         }
      }
   }

   public synchronized void actionPerformed( ActionEvent e )
   {
      try {
         display.append( "\nEnviando pacote contendo: " +
                         e.getActionCommand() + "\n" );

         String s = e.getActionCommand();
         byte data[] = s.getBytes();

         sendPacket = new DatagramPacket( data, data.length,
            grupo, 5000 );
         socket.send( sendPacket );
         display.append( "Pacote enviado\n" );
         display.setCaretPosition(
            display.getText().length() );

      }
      catch ( IOException exception ) {
         display.append( exception.toString() + "\n" );
         exception.printStackTrace();
      }
   }

   public static void main( String args[] )
   {
      Client app = new Client();

      app.addWindowListener(
         new WindowAdapter() {
            public void windowClosing( WindowEvent e )
            {
               System.exit( 0 );
            }
         }
      );

      app.waitForPackets();
   }
}

