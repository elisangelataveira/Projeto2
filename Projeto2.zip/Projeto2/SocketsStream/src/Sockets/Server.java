
package Sockets;

import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Server extends JFrame {
   private JTextField enter;
   private JTextArea display;
   ObjectOutputStream output;
   ObjectInputStream input;

   public Server()
   {
      super( "Servidor" );

      Container c = getContentPane();

      enter = new JTextField();
      enter.setEnabled( false );
      enter.addActionListener(
         new ActionListener() {
            public void actionPerformed( ActionEvent e )
            {
               sendData( e.getActionCommand() );
            }
         }
      );
      c.add( enter, BorderLayout.NORTH );

      display = new JTextArea();
      c.add( new JScrollPane( display ),
             BorderLayout.CENTER );

      setSize( 300, 150 );
      show();
   }

   public void runServer()
   {
      ServerSocket server;
      Socket connection;
      int counter = 1;

      try {
         // Etapa 1: Cria um ServerSocket.
         server = new ServerSocket( 5050, 100 );

         while ( true ) {
            // Etapa 2: Espera por uma connection.
            display.setText( "Esperando por conexão\n" );
            connection = server.accept();
            
            display.append( "Conexão " + counter +
               " recebida de: " +
               connection.getInetAddress().getHostName() );

            // Etapa 3: Obter Entrada e saída de streams.
            output = new ObjectOutputStream(
                         connection.getOutputStream() );
            output.flush();
            input = new ObjectInputStream(
                        connection.getInputStream() );
            display.append( "\nObter I/O streams\n" );
 
            // Etapa 4: Processar connection.
            String message =
               "SERVIDOR>>> Conexão bem sucedida";
            output.writeObject( message );
            output.flush();
            enter.setEnabled( true );

            do {
               try {
                  message = (String) input.readObject();
                  display.append( "\n" + message );
                  display.setCaretPosition(
                     display.getText().length() );
               }
               catch ( ClassNotFoundException cnfex ) {
                  display.append(
                     "\nUnknown object type received" );
               }
            } while ( !message.equals( "CLIENTE>>> ENCERRAR" ) );

            // Etapa 5: Fechar connection.
            display.append( "\nUsuário encerrou conexão " );
            enter.setEnabled( false );
            output.close();
            input.close();
            connection.close();

            ++counter;
         }
      }
      catch ( EOFException eof ) {
         System.out.println( "Client terminated connection" );
      }
      catch ( IOException io ) {
         io.printStackTrace();
      }
   }

   private void sendData( String s )
   {
      try {
         output.writeObject( "SERVIDOR>>> " + s );
         output.flush();
         display.append( "\nSERVIDOR>>>" + s );
      }
      catch ( IOException cnfex ) {
         display.append(
            "\nError writing object" );
      }
   }

   public static void main( String args[] )
   {
      Server app = new Server();

      app.addWindowListener(
         new WindowAdapter() {
            public void windowClosing( WindowEvent e )
            {
               System.exit( 0 );
            }
         }
      );

      app.runServer();
   }
}

